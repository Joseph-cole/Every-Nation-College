import { StyleSheet } from 'react-native';

const globalStyle = StyleSheet.create({
  container: {
    backgroundColor: '#f5f5f5',
    flex: 1,
  },
  andriodStyle: {
    paddingTop: 40,
  },
  andriodPadding: {
    padding: 5,
    paddingBottom: 1,
  },
  titleView: {
    backgroundColor: '#ddd',
    padding: 20,
    marginBottom: 15,
  },  
  paddingScrollView: {
    marginBottom: 70
  },
  title: {
    fontSize: 25,
    textAlign: 'center',
    fontWeight: '800',
    color: '#333',
    textTransform: 'capitalize',
  },
  textTitleView: {
    backgroundColor: '#fff',
    paddingLeft: 5,
    paddingRight: 5,
    borderRadius: 10,
    width: '99%',
    marginTop: 20,
    marginRight: 10,
  },
  textTitle: {
    fontSize: 30,
    color: '#555',
    fontWeight: '700',
    marginBottom: 10,
  },
  overView: {
    backgroundColor: '#2282',
    padding: 20,
    margin: '1%',
    borderRadius: 10,
    marginBottom: 10,
  },
  textTitleSmall: {
    fontSize: 20,
    textTransform: 'capitalize',
    color: '#555',
    fontWeight: '700',
    marginBottom: 10,
  },
  currency: {
    fontSize: 25,
    color: '#cc',
    fontWeight: '800',
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
    elevation: 3, // Adds shadow on Android
    shadowColor: '#000', // For iOS shadow
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  displayFlex: {
    display: 'flex',
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  displayText: {
    textTransform: 'capitalize',
    fontWeight: '600',
  },
  displayFlexFooter: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#ddd',
    padding: 10,
    paddingBottom: 20,
    zIndex: 1,
  },
  footerBox: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center', 
      flexDirection: 'column',
      padding: 10,
  },
  footerBoxText: {
    textTransform: 'capitalize',
    fontWeight: 800
  },
  displayCol: {
    display: 'flex',
    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingLeft: 10,
    paddingRight: 10,
    alignItems: 'center',
  },
  plusBtn: {
    backgroundColor: '#333',
    borderRadius: '50%',
    width: 45,
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
  }
});

export default globalStyle;