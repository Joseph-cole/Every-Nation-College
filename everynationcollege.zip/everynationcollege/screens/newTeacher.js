import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles

const NewTeacher = ({ navigation }) => {
  const [name, setName] = useState("");
  const [sex, setSex] = useState("");
  const [moduleTaught, setModuleTaught] = useState("");
  const [salary, setSalary] = useState("");

  const handleSaveData = async () => {
    // Basic form validation
    if (!name || !sex || !moduleTaught || !salary) {
      Alert.alert("Error", "Please fill all fields.");
      return;
    }

    try {
      const response = await fetch('http://enc.myartsonline.com/add_teacher.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `name=${encodeURIComponent(name)}&sex=${encodeURIComponent(sex)}&module_taught=${encodeURIComponent(moduleTaught)}&salary=${encodeURIComponent(salary)}`,
      });

      const data = await response.json();

      if (data.success) {
        Alert.alert("Success", data.message);
        // Optionally, reset the form fields or navigate to another screen
      } else {
        Alert.alert("Error", data.message);
      }
    } catch (error) {
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add a New Teacher</Text>
      
      {/* Name input */}
      <TextInput
        style={styles.input}
        placeholder="Teacher's Name"
        value={name}
        onChangeText={setName}
        placeholderTextColor="#888"
        autoCapitalize="words"
      />
      
      {/* Sex input */}
      <TextInput
        style={styles.input}
        placeholder="Sex (Male/Female)"
        value={sex}
        onChangeText={setSex}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      
      {/* Module Taught input */}
      <TextInput
        style={styles.input}
        placeholder="Module Taught"
        value={moduleTaught}
        onChangeText={setModuleTaught}
        placeholderTextColor="#888"
        autoCapitalize="words"
      />
      
      {/* Salary input */}
      <TextInput
        style={styles.input}
        placeholder="Salary"
        value={salary}
        onChangeText={setSalary}
        placeholderTextColor="#888"
        keyboardType="numeric"
      />
      
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Teacher</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewTeacher;
