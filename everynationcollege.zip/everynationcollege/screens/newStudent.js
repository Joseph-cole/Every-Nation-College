import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewStudent = ({ navigation }) => {
  const [name, setName] = useState("");
  const [idnum, setIdnum] = useState("");
  const [sex, setSex] = useState("");
  const [program, setProgram] = useState("");
  const [year, setYear] = useState("");

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      // Make sure all fields are filled
      if (!name || !idnum || !sex || !program || !year) {
        Alert.alert("Error", "Please fill all fields.");
        return;
      }

      // Send the collected data to the server
      const response = await fetch('http://enc.myartsonline.com/add_student.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `name=${encodeURIComponent(name)}&idnum=${encodeURIComponent(idnum)}&sex=${encodeURIComponent(sex)}&program=${encodeURIComponent(program)}&year=${encodeURIComponent(year)}`,
      });

      const data = await response.json();
      Alert.alert(data.message);
      
    } catch (error) {
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Student</Text>

      {/* Name Input */}
      <TextInput
        style={styles.input}
        placeholder="Student's Name"
        value={name}
        onChangeText={setName}
        placeholderTextColor="#888"
        autoCapitalize="words"
      />

      {/* ID Number Input */}
      <TextInput
        style={styles.input}
        placeholder="Student ID Number"
        value={idnum}
        onChangeText={setIdnum}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />

      {/* Sex Input */}
      <TextInput
        style={styles.input}
        placeholder="Sex (Male/Female)"
        value={sex}
        onChangeText={setSex}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />

      {/* Program Input */}
      <TextInput
        style={styles.input}
        placeholder="Program"
        value={program}
        onChangeText={setProgram}
        placeholderTextColor="#888"
        autoCapitalize="words"
      />

      {/* Year Input */}
      <TextInput
        style={styles.input}
        placeholder="Year"
        value={year}
        onChangeText={setYear}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />

      {/* Save Button */}
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewStudent; // Ensure NewStudent is exported for collection of data
