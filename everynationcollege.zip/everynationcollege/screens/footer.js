// components/Footer.js
import React from 'react';
import { View, TouchableOpacity, Text, Platform } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles'; // Adjust the import path as necessary

const Footer = ({ navigation }) => {
  return (
    <View style={[
      globalStyle.displayFlexFooter, 
      Platform.OS === 'android' ? globalStyle.andriodPadding : {}
    ]}>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('App')}>
        <Icon name="dashboard" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Board</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('History')}>
        <Icon name="history" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Record</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('NewTeacher')}>
        <Icon name="plus" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Teacher</Text>
      </TouchableOpacity>
       <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('NewStudent')}>
        <Icon name="plus" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Student</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Footer;