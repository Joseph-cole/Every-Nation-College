import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, Alert } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const App = ({ navigation }) => {
  const [spendingTrends, setSpendingTrends] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);
  const [totalStatistic, setTotalStatistic] = useState(0); // ✅ Add state for total statistic

  useEffect(() => {
    fetchData();
  }, []);

 const fetchData = async () => {
  try {
    // Fetch teacher data
    const teacherRes = await fetch('http://enc.myartsonline.com/fetch_teacher.php');
    const teacherData = await teacherRes.json();

    if (!Array.isArray(teacherData)) {
      Alert.alert('Error', `Unexpected teacher data format: ${JSON.stringify(teacherData)}`);
      return;
    }
    setTeachers(teacherData);

    // Fetch student data
    const studentRes = await fetch('http://enc.myartsonline.com/fetch_student.php');
    const studentData = await studentRes.json();

    if (!Array.isArray(studentData)) {
      Alert.alert('Error', `Unexpected student data format: ${JSON.stringify(studentData)}`);
      return;
    }
    setStudents(studentData);

    const statistic = await fetch('http://enc.myartsonline.com/fetch_statistic.php');
    const result = await statistic.json();
    if (!Array.isArray(result)){
       Alert.alert('Error', `Unexpected student data format: ${JSON.stringify(result)}`);
      return;
    }
    setTotalStatistic(result[0].total_teacher);

    const chart = await fetch('http://enc.myartsonline.com/results.php');
    const chartResponse = await chart.json();
    setSpendingTrends([
      {
        name: 'Teachers',
        population: parseInt(chartResponse[0].total_teacher, 10),  // Convert total_teacher to integer
        color: '#FF6384',
        legendFontColor: '#7F7F7F',
        legendFontSize: 15,
      },
      {
        name: 'Students',
        population: parseInt(chartResponse[1].total, 10),  // Convert total to integer
        color: '#36A2EB',
        legendFontColor: '#7F7F7F',
        legendFontSize: 15,
      }
    ]);


  } catch (error) {
    Alert.alert('Error', `Error fetching data: ${error.message}`);
  }
};


  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? globalStyle.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Dashboard</Text>
        </View>
        
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>College Data</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total Employee</Text>
            <Text style={globalStyle.currency}>{totalStatistic}</Text> {/* ✅ Updated to show total statistic */}
          </View>
          <Text style={globalStyle.textTitleSmall}>Employee and students per Category</Text>
          <PieChart
            data={spendingTrends}  // Using spendingTrends for the PieChart data
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"  // This should match the data field used
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        
        {/* Teachers Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Teachers</Text>
            <Text style={globalStyle.textTitleSmall}>Salary</Text>
          </View>
          {teachers.map((teacher, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{teacher.name}</Text>
              <Text style={globalStyle.displayText}>{teacher.salary}</Text>
            </View>
          ))}
        </View>

        {/* Students Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Students</Text>
            <Text style={globalStyle.textTitleSmall}>ID Num</Text>
          </View>
          {students.map((student, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{student.name}</Text>
              <Text style={globalStyle.displayText}>{student.idnum}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default App;
