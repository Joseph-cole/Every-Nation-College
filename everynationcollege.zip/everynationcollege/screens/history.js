import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, StatusBar, Alert } from 'react-native';
import styles from '../styles/dbStyles';
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const History = ({ navigation }) => {
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);  

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch teacher data
      const teacherRes = await fetch('http://enc.myartsonline.com/fetch_teacher.php');
      const teacherData = await teacherRes.json();

      if (Array.isArray(teacherData)) {
        setTeachers(teacherData);
      } else {
        Alert.alert('Error', `Unexpected teacher data format: ${JSON.stringify(teacherData)}`);
      }

      // Fetch student data
      const studentRes = await fetch('http://enc.myartsonline.com/fetch_student.php');
      const studentData = await studentRes.json();

      if (Array.isArray(studentData)) {
        setStudents(studentData);
      } else {
        Alert.alert('Error', `Unexpected student data format: ${JSON.stringify(studentData)}`);
      }

    } catch (error) {
      Alert.alert('Error', `Error fetching data: ${error.message}`);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>History</Text>
        </View>

        {/* Teachers Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Teachers</Text>
            <Text style={globalStyle.textTitleSmall}>Salary</Text>
          </View>
          {teachers.map((teacher, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{teacher.name}</Text>
              <Text style={globalStyle.displayText}>{teacher.salary}</Text>
            </View>
          ))}
        </View>

        {/* Students Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Students</Text>
            <Text style={globalStyle.textTitleSmall}>ID Num</Text>
          </View>
          {students.map((student, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{student.name}</Text>
              <Text style={globalStyle.displayText}>{student.idnum}</Text>
            </View>
          ))}
        </View>
      
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default History;