import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthProvider, useAuth } from './screens/AuthContext';
import Login from './screens/login';
import Signup from './screens/signup';
import App from './screens/dashboard';
import History from './screens/history';
import NewStudent from './screens/newStudent';
import NewTeacher from './screens/newTeacher';

const Stack = createNativeStackNavigator();

const Root = () => {
    return (
        <AuthProvider>
            <NavigationContainer>
                <MainNavigator />
            </NavigationContainer>
        </AuthProvider>
    );
};

const MainNavigator = () => {
    const { isAuthenticated } = useAuth();

    return (
        <Stack.Navigator initialRouteName="Login">
            {isAuthenticated ? (
                <>
                    <Stack.Screen 
                        name="App" 
                        component={App} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="History" 
                        component={History}  
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen
                      name="NewTeacher"
                      component={NewTeacher}
                      options={{ headerShown: true }}
                    />
                    <Stack.Screen
                      name="NewStudent"
                      component={NewStudent}
                      options={{ headerShown: true }}
                    />
                </>
            ) : (
                <>
                    <Stack.Screen 
                        name="Login" 
                        component={Login} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="Signup" 
                        component={Signup} 
                        options={{ headerShown: false }} 
                    />
                </>
            )}
        </Stack.Navigator>
    );
};

export default Root;